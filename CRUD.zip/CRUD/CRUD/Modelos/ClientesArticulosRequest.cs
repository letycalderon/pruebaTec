﻿namespace CRUD.Modelos
{
    public class ClientesArticulosRequest
    {
        public Guid ClienteId { get; set; }
        public Guid ArticuloId { get; set; }
    }
}
