﻿namespace CRUD.Modelos
{
    public class LoginRequest
    {
        public string Username { get; set; }
        public string Contraseña { get; set; }
    }
}
